"""The dataset, the feature contract, and what the model must not be.

The regression these guard against: a classifier trained on random numbers
whose labels were a rule over those same numbers, served with a different
feature set than it was trained on.
"""

from __future__ import annotations

import json
from pathlib import Path

import math

import numpy as np
import pytest

from backend.ml.dataset import FEATURES, LABEL, PAYEE_FEATURES, PAYER_FEATURES, generate
from backend.ml.features import build_features, build_vector, to_frame

ROOT = Path(__file__).resolve().parents[1]


# ── The dataset ───────────────────────────────────────────────────────────

def test_labels_are_not_a_rule_over_the_features():
    """The old script labelled rows with
       amount > 80000 | rolling_txn_count > 7 | time_gap < 50
    so the label was a deterministic function of the features. If any single
    feature threshold separates the classes perfectly, we have rebuilt that.
    """
    df = generate(20_000, seed=7)
    for col in FEATURES:
        legit = df.loc[df[LABEL] == 0, col]
        fraud = df.loc[df[LABEL] == 1, col]
        overlap = (legit.min() <= fraud.max()) and (fraud.min() <= legit.max())
        assert overlap, f"{col} separates the classes with no overlap"


def test_fraud_and_legitimate_ranges_genuinely_overlap():
    """Honest payments to new payees, and large honest payments, must exist -
    otherwise the problem is trivial and the metrics are meaningless."""
    df = generate(20_000, seed=7)
    legit = df[df[LABEL] == 0]
    assert legit["payee_is_new"].mean() > 0.10
    assert (legit["amount_over_user_avg"] > 5).mean() > 0.03
    fraud = df[df[LABEL] == 1]
    assert (fraud["payee_age_days"] > 180).mean() > 0.05


def test_every_scenario_is_represented():
    df = generate(30_000, seed=3)
    kinds = set(df.loc[df[LABEL] == 1, "scenario"])
    assert kinds == {"social_engineering", "mule_collection", "account_takeover", "card_testing"}


def test_feature_groups_partition_the_feature_set():
    assert set(PAYER_FEATURES) | set(PAYEE_FEATURES) == set(FEATURES)
    assert not set(PAYER_FEATURES) & set(PAYEE_FEATURES)


def test_generation_is_reproducible():
    a = generate(2_000, seed=11)
    b = generate(2_000, seed=11)
    assert a[FEATURES].equals(b[FEATURES])


# ── The serving feature contract ──────────────────────────────────────────

def test_build_features_produces_exactly_the_trained_columns():
    f = build_features(amount=500, timestamp="2026-09-09T13:00:00")
    assert set(f) == set(FEATURES)
    assert list(to_frame(f).columns) == FEATURES


def test_column_order_is_fixed_not_dict_order():
    f = build_features(amount=500, timestamp="2026-09-09T13:00:00")
    shuffled = dict(reversed(list(f.items())))
    assert list(to_frame(shuffled).columns) == FEATURES
    assert to_frame(shuffled).equals(to_frame(f))


def test_an_unknown_payee_reports_no_history_rather_than_a_substitute():
    """An unknown payee must produce *no* value, not a plausible one.

    This assertion has been through two wrong versions, and both wrongs point
    the same way. First the code defaulted a missing age to 0, which invents
    the strongest fraud signal there is: a zero-day-old account. The fix
    substituted population-typical constants instead - 180 days, 8 payers, a
    0.4 repeat ratio - and this test asserted `> 0`, which those satisfied.

    But a constant is still an invention. 180 days old with 8 payers describes
    a payee with a modest real track record, and it was being asserted of every
    address the system had never seen - including one a mule opened yesterday.
    The test was passing while the bug it was written to prevent had merely
    changed shape.

    The contract now is absence: NaN, an availability flag that says so, and
    nothing the model can mistake for a measurement.
    """
    v = build_vector(amount=500, timestamp="2026-09-09T13:00:00", reputation={})

    for name in ("payee_age_days", "payee_distinct_payers", "payee_repeat_ratio"):
        assert math.isnan(v.values[name]), f"{name} was filled in for an unknown payee"
        assert v.available[name] is False

    assert v.values["payee_history_available"] == 0.0
    assert v.payee_history_available is False
    # The original bug, still guarded: absent must not read as zero.
    assert v.values["payee_age_days"] != 0


def test_known_payee_values_come_from_the_reputation_store():
    f = build_features(
        amount=500, timestamp="2026-09-09T13:00:00",
        reputation={"known": True, "age_days": 9, "distinct_payers": 24, "repeat_payers": 0},
    )
    assert f["payee_age_days"] == 9
    assert f["payee_distinct_payers"] == 24
    assert f["payee_repeat_ratio"] == 0
    # With no payer supplied, "new" falls back to "have we seen this payee at
    # all" - and we have. This assertion used to read == 1, encoding the bug
    # it was meant to guard: payee_is_new was computed from the payee's repeat
    # payers, a property of the payee's whole network, when the model was
    # trained on "has THIS payer paid THIS payee before".
    assert f["payee_is_new"] == 0


def test_payee_is_new_follows_the_payer_not_the_payee_network():
    """The feature the model was actually trained on."""
    known_payee = {"known": True, "age_days": 400, "distinct_payers": 90, "repeat_payers": 60}
    first_time = build_features(500, None, reputation=known_payee, payer_seen_payee_before=False)
    returning = build_features(500, None, reputation=known_payee, payer_seen_payee_before=True)
    assert first_time["payee_is_new"] == 1, "a well-established payee is still new to a first-time payer"
    assert returning["payee_is_new"] == 0


def test_a_known_payee_with_no_recorded_age_is_not_called_zero_days_old():
    """age_days is None when payers exist but no reputation row does.

    Guarding on `known` alone let that None become 0.0 - a zero-day-old
    account, which is the strongest mule signal the model has.
    """
    v = build_vector(
        500, None,
        reputation={"known": True, "age_days": None, "distinct_payers": 3, "repeat_payers": 0},
    )
    assert math.isnan(v.values["payee_age_days"])
    assert v.available["payee_age_days"] is False

    # Three payers is also below the floor at which a repeat ratio means
    # anything: three people who each paid once give a ratio of exactly 0.0,
    # which is the signature of a collection account and is actually an empty
    # sample. Both reasons point at the same answer - say nothing.
    assert math.isnan(v.values["payee_repeat_ratio"])


def test_the_amount_ratio_uses_the_median_the_model_was_trained_on():
    profile = {"avg_amount": 431.5, "median_amount": 300.0}
    assert build_features(600, None, profile=profile)["amount_over_user_avg"] == 2.0
    # Older profiles have no median; fall back rather than failing.
    assert build_features(600, None, profile={"avg_amount": 300.0})["amount_over_user_avg"] == 2.0


def test_night_and_hour_distance():
    night = build_features(amount=100, timestamp="2026-09-09T23:30:00",
                           profile={"most_active_hour": 13})
    assert night["is_night"] == 1
    assert night["hours_from_usual"] == pytest.approx(10)

    day = build_features(amount=100, timestamp="2026-09-09T13:00:00",
                         profile={"most_active_hour": 13})
    assert day["is_night"] == 0
    assert day["hours_from_usual"] == 0


def test_unknown_usual_hour_is_not_treated_as_maximally_unusual():
    f = build_features(amount=100, timestamp="2026-09-09T03:00:00", profile={})
    assert f["hours_from_usual"] == 0


# ── The published metrics ─────────────────────────────────────────────────

@pytest.mark.skipif(not (ROOT / "models" / "metrics.json").exists(),
                    reason="run python backend/train_model.py first")
def test_metrics_report_what_matters_and_state_the_caveat():
    m = json.loads((ROOT / "models" / "metrics.json").read_text())
    assert "simulated" in m["data"]["source"]
    assert "No public labelled UPI fraud dataset" in m["data"]["caveat"]
    for key in ("pr_auc", "roc_auc", "operating_point", "recall_by_scenario"):
        assert key in m["selected"]
    assert m["selected"]["operating_point"]["fpr_budget"] == 0.01
    # A near-perfect PR-AUC on simulated data means the simulator is separable,
    # not that the model is good.
    assert m["selected"]["pr_auc"] < 0.95, "suspiciously high - check the generator"


@pytest.mark.skipif(not (ROOT / "models" / "metrics.json").exists(),
                    reason="run python backend/train_model.py first")
def test_the_ablation_supports_the_projects_claim():
    m = json.loads((ROOT / "models" / "metrics.json").read_text())
    se = m["ablation"]["social_engineering_recall"]
    assert se["both"] > se["payer_only"], (
        "payee signals must add something on the case the payer cannot see"
    )
